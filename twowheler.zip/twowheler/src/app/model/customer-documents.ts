export class CustomerDocuments {
    customerDocumentsId:number;
    customerId:number;
    profilePhoto:[];
    signature:[];
    pancard:[];
    bankcheque:[];
    salaryslip:[];
    bankStatement:[];
    addressProof:[]
}
