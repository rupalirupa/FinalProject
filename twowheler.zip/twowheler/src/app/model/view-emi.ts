export class ViewEmi {

    emiid:number;
    customerId:number;
   agreementDate:string;
    loanAmtSanctioned:number;
    
    rateOfInterest:number;
    loanTenure:number;
    monthlyEmiAmount:number;
    num:number;
    status:string;

}
