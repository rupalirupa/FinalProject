import { ViewEmi } from './view-emi';

describe('ViewEmi', () => {
  it('should create an instance', () => {
    expect(new ViewEmi()).toBeTruthy();
  });
});
