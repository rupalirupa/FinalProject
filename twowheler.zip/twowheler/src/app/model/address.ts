export class Address {
    permanentAddressId:number
areaname:string
cityname:string 
district:string
state:string
pincode:number


}
