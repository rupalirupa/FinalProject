export class AccountDetail {

    accountId:number;
accountHolderName:string;
accountNumber:number;
}
