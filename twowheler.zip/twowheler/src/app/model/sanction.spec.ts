import { Sanction } from './sanction';

describe('Sanction', () => {
  it('should create an instance', () => {
    expect(new Sanction()).toBeTruthy();
  });
});
