export class GuarantorDetails {
    guarantorId:number;
guarantorName:string;
guarantorMobileNo:number;
guarantorPermanentAddress:string;
}
