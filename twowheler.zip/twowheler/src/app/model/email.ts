export class Email {
    id:number
    name:string
	sender:string
	receiver:string
    status:string
	
}
