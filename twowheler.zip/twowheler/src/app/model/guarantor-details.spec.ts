import { GuarantorDetails } from './guarantor-details';

describe('GuarantorDetails', () => {
  it('should create an instance', () => {
    expect(new GuarantorDetails()).toBeTruthy();
  });
});
