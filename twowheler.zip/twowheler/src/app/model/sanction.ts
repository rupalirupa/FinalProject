export class Sanction {
    sanctionId:number;
	sanctionDate:string;
	applicantName:string;
	 contactDetails:number;
	 loanAmtSanctioned:number;
	interestType:string;
	rateOfInterest:number
	loanTenure:number;
	monthlyEmiAmount:number;
	modeOfPayment:string;
	status:string;
}
