export class Enquiry 
{
    cid:number;
    firstName:string;
    lastName:string;
    status:string;
    age:number;
    email:string;
    mobileNo:number;
    pancardNo:string;
    cibilscore:number;
}
