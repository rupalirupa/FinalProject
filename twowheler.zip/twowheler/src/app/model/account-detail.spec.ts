import { AccountDetail } from './account-detail';

describe('AccountDetail', () => {
  it('should create an instance', () => {
    expect(new AccountDetail()).toBeTruthy();
  });
});
