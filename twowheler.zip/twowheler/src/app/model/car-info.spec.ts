import { CarInfo } from './car-info';

describe('CarInfo', () => {
  it('should create an instance', () => {
    expect(new CarInfo()).toBeTruthy();
  });
});
