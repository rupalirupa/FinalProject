export class Profession {
    professionId:number;
    professionType:string;
    professionSalary:number;
    professionSalaryType:string;
    workingFrom:string;
    professionDesignation:string;
}
