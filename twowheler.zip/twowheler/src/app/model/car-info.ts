export class CarInfo {
    carId:number;
    carModelNo:number;
carName:string;
brandName:string;
carPrice:number;
colour:string;
}
