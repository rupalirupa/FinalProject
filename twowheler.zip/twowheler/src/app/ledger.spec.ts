import { Ledger } from './model/ledger';

describe('Ledger', () => {
  it('should create an instance', () => {
    expect(new Ledger()).toBeTruthy();
  });
});
