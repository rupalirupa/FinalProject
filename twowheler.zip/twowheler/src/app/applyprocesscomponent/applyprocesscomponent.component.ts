import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applyprocesscomponent',
  templateUrl: './applyprocesscomponent.component.html',
  styleUrls: ['./applyprocesscomponent.component.css']
})
export class ApplyprocesscomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
